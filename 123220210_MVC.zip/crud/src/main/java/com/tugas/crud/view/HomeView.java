/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;

import javax.swing.*;
import java.awt.event.ActionListener;

public class HomeView extends JFrame {
    private JButton dosenButton = new JButton("Dosen");
    private JButton mahasiswaButton = new JButton("Mahasiswa");

    public HomeView() {
        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300, 200);

        panel.add(dosenButton);
        panel.add(mahasiswaButton);

        this.add(panel);
    }

    public void addDosenListener(ActionListener listenForDosenButton) {
        dosenButton.addActionListener(listenForDosenButton);
    }

    public void addMahasiswaListener(ActionListener listenForMahasiswaButton) {
        mahasiswaButton.addActionListener(listenForMahasiswaButton);
    }
}
