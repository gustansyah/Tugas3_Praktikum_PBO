/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;





import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;

public class MahasiswaView extends JFrame {
    private JTable mahasiswaTable;
    private DefaultTableModel tableModel;
    private JButton addButton = new JButton("Add New Mahasiswa");
    private JButton backButton = new JButton("Back");

    public MahasiswaView() {
        // Initialize table
        String[] columnNames = {"ID", "Nama", "NIM", "Edit", "Delete"};
        tableModel = new DefaultTableModel(columnNames, 0);
        mahasiswaTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3 || column == 4; // Only edit and delete columns are editable
            }
        };

        mahasiswaTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        mahasiswaTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));
        mahasiswaTable.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        mahasiswaTable.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox()));

        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 600);

        JScrollPane scrollPane = new JScrollPane(mahasiswaTable);
        panel.add(scrollPane);

        panel.add(addButton);
        panel.add(backButton);

        this.add(panel);
    }

    public void addMahasiswa(String id, String nama, String nim) {
        tableModel.addRow(new Object[]{id, nama, nim, "Edit", "Delete"});
    }

    public int getSelectedRow() {
        return mahasiswaTable.getSelectedRow();
    }

    public JTable getTable() {
        return mahasiswaTable;
    }

    public void addAddListener(ActionListener listenForAddButton) {
        addButton.addActionListener(listenForAddButton);
    }

    public void addBackListener(ActionListener listenForBackButton) {
        backButton.addActionListener(listenForBackButton);
    }

    public void addEditListener(ActionListener listenForEditButton) {
        mahasiswaTable.getColumnModel().getColumn(3).getCellEditor().addCellEditorListener(new TableCellListener(mahasiswaTable, listenForEditButton));
    }

    public void addDeleteListener(ActionListener listenForDeleteButton) {
        mahasiswaTable.getColumnModel().getColumn(4).getCellEditor().addCellEditorListener(new TableCellListener(mahasiswaTable, listenForDeleteButton));
    }

    public void clearTable() {
        tableModel.setRowCount(0);
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showError(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage);
    }
}
