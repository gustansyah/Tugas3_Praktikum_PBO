/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;

import com.tugas.crud.model.DosenDAO;
import com.tugas.crud.model.Dosen;
import com.tugas.crud.view.DosenFormView;
import com.tugas.crud.view.DosenView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class DosenController {
    private DosenView dosenView;
    private DosenFormView dosenFormView;
    private DosenDAO dosenDAO;

    public DosenController(DosenView dosenView, DosenDAO dosenDAO) {
        this.dosenView = dosenView;
        this.dosenDAO = dosenDAO;

        this.dosenView.addAddListener(new AddButtonListener());
        this.dosenView.addBackListener(new BackButtonListener());
        this.dosenView.addEditListener(new EditButtonListener());
        this.dosenView.addDeleteListener(new DeleteButtonListener());

        loadDosenData();
    }

    class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenFormView = new DosenFormView();
            dosenFormView.addSaveListener(new SaveButtonListener());
            dosenFormView.addBackListener(new FormBackButtonListener());
            dosenFormView.setVisible(true);
        }
    }

    class EditButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = dosenView.getSelectedRow();
            if (selectedRow >= 0) {
                String id = dosenView.getTable().getValueAt(selectedRow, 0).toString();
                String nama = dosenView.getTable().getValueAt(selectedRow, 1).toString();
                String nidn = dosenView.getTable().getValueAt(selectedRow, 2).toString();

                dosenFormView = new DosenFormView();
                dosenFormView.setId(id);
                dosenFormView.setNama(nama);
                dosenFormView.setNidn(nidn);
                dosenFormView.addSaveListener(new SaveButtonListener());
                dosenFormView.addBackListener(new FormBackButtonListener());
                dosenFormView.setVisible(true);
            }
        }
    }

    class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String id = dosenFormView.getId();
            String nama = dosenFormView.getNama();
            String nidn = dosenFormView.getNidn();

            if (id.isEmpty()) {
                // Add new dosen
                Dosen dosen = new Dosen(0, nama, nidn);
                dosenDAO.addDosen(dosen);
            } else {
                // Update existing dosen
                Dosen dosen = new Dosen(Integer.parseInt(id), nama, nidn);
                dosenDAO.updateDosen(dosen);
            }
            dosenFormView.dispose();
            loadDosenData();
        }
    }

    class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = dosenView.getSelectedRow();
            if (selectedRow >= 0) {
                String id = dosenView.getTable().getValueAt(selectedRow, 0).toString();
                dosenDAO.deleteDosen(Integer.parseInt(id));
                loadDosenData();
            }
        }
    }

    class FormBackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenFormView.dispose();
        }
    }

    class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenView.setVisible(false);
            // Assuming home view is passed and managed correctly
        }
    }

    private void loadDosenData() {
        List<Dosen> dosenList = dosenDAO.getAllDosen();
        dosenView.clearTable();
        for (Dosen dosen : dosenList) {
            dosenView.addDosen(String.valueOf(dosen.getId()), dosen.getNama(), dosen.getNidn());
        }
    }
}