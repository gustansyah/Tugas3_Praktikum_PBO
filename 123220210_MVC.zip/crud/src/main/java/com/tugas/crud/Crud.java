/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud;

import com.tugas.crud.controller.DosenController;
import com.tugas.crud.controller.HomeController;
import com.tugas.crud.controller.MahasiswaController;
import com.tugas.crud.model.DosenDAO;
import com.tugas.crud.model.MahasiswaDAO;
import com.tugas.crud.view.DosenView;
import com.tugas.crud.view.HomeView;
import com.tugas.crud.view.MahasiswaView;

public class Crud {
    public static void main(String[] args) {
        // Initialize views
        HomeView homeView = new HomeView();
        DosenView dosenView = new DosenView();
        MahasiswaView mahasiswaView = new MahasiswaView();

        // Initialize DAOs
        DosenDAO dosenDAO = new DosenDAO();
        MahasiswaDAO mahasiswaDAO = new MahasiswaDAO();

        // Initialize controllers
        DosenController dosenController = new DosenController(dosenView, dosenDAO);
        MahasiswaController mahasiswaController = new MahasiswaController(mahasiswaView, mahasiswaDAO);
        HomeController homeController = new HomeController(homeView, dosenView, mahasiswaView);

        // Show home view
        homeView.setVisible(true);
    }
}
