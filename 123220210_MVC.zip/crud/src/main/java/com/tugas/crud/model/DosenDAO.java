/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.model;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DosenDAO {
    private final String url = "jdbc:mysql://localhost:3306/upnvy";
    private final String user = "root";
    private final String password = "";

    public void addDosen(Dosen dosen) {
        String query = "INSERT INTO dosen (nama, nidn) VALUES (?, ?)";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, dosen.getNama());
            statement.setString(2, dosen.getNidn());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDosen(Dosen dosen) {
        String query = "UPDATE dosen SET nama = ?, nidn = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, dosen.getNama());
            statement.setString(2, dosen.getNidn());
            statement.setInt(3, dosen.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDosen(int id) {
        String query = "DELETE FROM dosen WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Dosen> getAllDosen() {
        List<Dosen> dosenList = new ArrayList<>();
        String query = "SELECT * FROM dosen";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nama = resultSet.getString("nama");
                String nidn = resultSet.getString("nidn");
                dosenList.add(new Dosen(id, nama, nidn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dosenList;
    }
}