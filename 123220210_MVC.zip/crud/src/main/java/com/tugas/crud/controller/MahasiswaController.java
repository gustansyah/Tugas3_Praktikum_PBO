/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;

import com.tugas.crud.model.MahasiswaDAO;
import com.tugas.crud.model.Mahasiswa;
import com.tugas.crud.view.MahasiswaFormView;
import com.tugas.crud.view.MahasiswaView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MahasiswaController {
    private MahasiswaView mahasiswaView;
    private MahasiswaFormView mahasiswaFormView;
    private MahasiswaDAO mahasiswaDAO;

    public MahasiswaController(MahasiswaView mahasiswaView, MahasiswaDAO mahasiswaDAO) {
        this.mahasiswaView = mahasiswaView;
        this.mahasiswaDAO = mahasiswaDAO;

        this.mahasiswaView.addAddListener(new AddButtonListener());
        this.mahasiswaView.addBackListener(new BackButtonListener());
        this.mahasiswaView.addEditListener(new EditButtonListener());
        this.mahasiswaView.addDeleteListener(new DeleteButtonListener());

        loadMahasiswaData();
    }

    class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mahasiswaFormView = new MahasiswaFormView();
            mahasiswaFormView.addSaveListener(new SaveButtonListener());
            mahasiswaFormView.addBackListener(new FormBackButtonListener());
            mahasiswaFormView.setVisible(true);
        }
    }

    class EditButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = mahasiswaView.getSelectedRow();
            String id = mahasiswaView.getTable().getValueAt(selectedRow, 0).toString();
            String nama = mahasiswaView.getTable().getValueAt(selectedRow, 1).toString();
            String nim = mahasiswaView.getTable().getValueAt(selectedRow, 2).toString();

            mahasiswaFormView = new MahasiswaFormView();
            mahasiswaFormView.setId(id);
            mahasiswaFormView.setNama(nama);
            mahasiswaFormView.setNim(nim);
            mahasiswaFormView.addSaveListener(new SaveButtonListener());
            mahasiswaFormView.addBackListener(new FormBackButtonListener());
            mahasiswaFormView.setVisible(true);
        }
    }

    class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String id = mahasiswaFormView.getId();
            String nama = mahasiswaFormView.getNama();
            String nim = mahasiswaFormView.getNim();

            if (id.isEmpty()) {
                // Add new mahasiswa
                Mahasiswa mahasiswa = new Mahasiswa(0, nama, nim);
                mahasiswaDAO.addMahasiswa(mahasiswa);
            } else {
                // Update existing mahasiswa
                Mahasiswa mahasiswa = new Mahasiswa(Integer.parseInt(id), nama, nim);
                mahasiswaDAO.updateMahasiswa(mahasiswa);
            }
            mahasiswaFormView.dispose();
            loadMahasiswaData();
        }
    }

    class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = mahasiswaView.getSelectedRow();
            String id = mahasiswaView.getTable().getValueAt(selectedRow, 0).toString();
            mahasiswaDAO.deleteMahasiswa(Integer.parseInt(id));
            loadMahasiswaData();
        }
    }

    class FormBackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mahasiswaFormView.dispose();
        }
    }

    class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mahasiswaView.setVisible(false);
            // Assuming home view is passed and managed correctly
        }
    }

    private void loadMahasiswaData() {
        List<Mahasiswa> mahasiswaList = mahasiswaDAO.getAllMahasiswa();
        mahasiswaView.clearTable();
        for (Mahasiswa mahasiswa : mahasiswaList) {
            mahasiswaView.addMahasiswa(String.valueOf(mahasiswa.getId()), mahasiswa.getNama(), mahasiswa.getNim());
        }
    }
}