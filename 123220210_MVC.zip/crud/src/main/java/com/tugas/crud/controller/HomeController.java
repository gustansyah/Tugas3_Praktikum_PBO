/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;





import com.tugas.crud.view.DosenView;
import com.tugas.crud.view.HomeView;
import com.tugas.crud.view.MahasiswaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeController {
    private HomeView homeView;
    private DosenView dosenView;
    private MahasiswaView mahasiswaView;

    public HomeController(HomeView homeView, DosenView dosenView, MahasiswaView mahasiswaView) {
        this.homeView = homeView;
        this.dosenView = dosenView;
        this.mahasiswaView = mahasiswaView;

        this.homeView.addDosenListener(new DosenButtonListener());
        this.homeView.addMahasiswaListener(new MahasiswaButtonListener());
        this.dosenView.addBackListener(new BackButtonListener());
        this.mahasiswaView.addBackListener(new BackButtonListener());
    }

    class DosenButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            homeView.setVisible(false);
            dosenView.setVisible(true);
        }
    }

    class MahasiswaButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            homeView.setVisible(false);
            mahasiswaView.setVisible(true);
        }
    }

    class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenView.setVisible(false);
            mahasiswaView.setVisible(false);
            homeView.setVisible(true);
        }
    }
}
