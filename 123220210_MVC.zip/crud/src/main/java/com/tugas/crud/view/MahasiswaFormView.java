/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;



import javax.swing.*;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class MahasiswaFormView extends JFrame {
    private JTextField idField = new JTextField(5);
    private JTextField namaField = new JTextField(20);
    private JTextField nimField = new JTextField(20);
    private JButton saveButton = new JButton("Save");
    private JButton backButton = new JButton("Back");

    public MahasiswaFormView() {
        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(400, 300);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("ID:"));
        panel.add(idField);
        idField.setEditable(false); // ID should not be editable

        panel.add(new JLabel("Nama:"));
        panel.add(namaField);

        panel.add(new JLabel("NIM:"));
        panel.add(nimField);

        panel.add(saveButton);
        panel.add(backButton);

        this.add(panel);
    }

    public String getId() {
        return idField.getText();
    }

    public String getNama() {
        return namaField.getText();
    }

    public String getNim() {
        return nimField.getText();
    }

    public void setId(String id) {
        idField.setText(id);
    }

    public void setNama(String nama) {
        namaField.setText(nama);
    }

    public void setNim(String nim) {
        nimField.setText(nim);
    }

    public void addSaveListener(ActionListener listenForSaveButton) {
        saveButton.addActionListener(listenForSaveButton);
    }

    public void addBackListener(ActionListener listenForBackButton) {
        backButton.addActionListener(listenForBackButton);
    }
}
